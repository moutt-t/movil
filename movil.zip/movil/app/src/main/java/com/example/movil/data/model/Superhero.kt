package com.example.movil.data.model

import com.google.gson.annotations.SerializedName

data class Superhero(
    @SerializedName("id") val id: Int,
    @SerializedName("name") val name: String,
    @SerializedName("slug") val slug: String?,
    @SerializedName("powerstats") val powerstats: Powerstats?,
    @SerializedName("appearance") val appearance: Appearance?,
    @SerializedName("biography") val biography: Biography?,
    @SerializedName("work") val work: Work?,
    @SerializedName("connections") val connections: Connections?,
    @SerializedName("images") val images: SuperheroImage?
)

data class Powerstats(
    @SerializedName("intelligence") val intelligence: Int = 0,
    @SerializedName("strength") val strength: Int = 0,
    @SerializedName("speed") val speed: Int = 0,
    @SerializedName("durability") val durability: Int = 0,
    @SerializedName("power") val power: Int = 0,
    @SerializedName("combat") val combat: Int = 0
)

data class Appearance(
    @SerializedName("gender") val gender: String?,
    @SerializedName("race") val race: String?,
    @SerializedName("height") val height: List<String>?,
    @SerializedName("weight") val weight: List<String>?,
    @SerializedName("eyeColor") val eyeColor: String?,
    @SerializedName("hairColor") val hairColor: String?
)

data class Biography(
    @SerializedName("fullName") val fullName: String?,
    @SerializedName("alterEgos") val alterEgos: String?,
    @SerializedName("aliases") val aliases: List<String>?,
    @SerializedName("placeOfBirth") val placeOfBirth: String?,
    @SerializedName("firstAppearance") val firstAppearance: String?,
    @SerializedName("publisher") val publisher: String?,
    @SerializedName("alignment") val alignment: String?
)

data class Work(
    @SerializedName("occupation") val occupation: String?,
    @SerializedName("base") val base: String?
)

data class Connections(
    @SerializedName("groupAffiliation") val groupAffiliation: String?,
    @SerializedName("relatives") val relatives: String?
)

data class SuperheroImage(
    @SerializedName("xs") val xs: String?,
    @SerializedName("sm") val sm: String?,
    @SerializedName("md") val md: String?,
    @SerializedName("lg") val lg: String?
)
