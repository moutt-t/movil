package com.example.movil.data.remote

import com.example.movil.data.model.Superhero
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Path

interface SuperheroApiService {

    @GET("all.json")
    suspend fun getSuperheroes(): Response<List<Superhero>>

    @GET("id/{id}.json")
    suspend fun getSuperheroById(
        @Path("id") id: Int
    ): Response<Superhero>
}
