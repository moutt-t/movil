package com.example.movil.ui.screens.detail

import com.example.movil.data.model.Superhero

data class DetailState(
    val hero: Superhero? = null,
    val isLoading: Boolean = false,
    val error: String? = null
)
