package com.example.movil.ui.screens.home

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.movil.data.model.Superhero
import com.example.movil.ui.components.ErrorStateComponent
import com.example.movil.ui.components.LoadingStateComponent
import com.example.movil.ui.screens.home.components.SearchBarComponent
import com.example.movil.ui.screens.home.components.SuperheroCard

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onHeroClick: (Int) -> Unit,
    viewModel: HomeViewModel = viewModel()
) {
    val state by viewModel.homeState.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "🦸‍♂️ Superhéroes API",
                        fontWeight = FontWeight.Bold
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when {
                state.isLoading -> {
                    LoadingStateComponent(message = "Cargando superhéroes...")
                }

                state.error != null -> {
                    ErrorStateComponent(
                        message = state.error ?: "Error desconocido",
                        onRetry = { viewModel.loadSuperheroes() }
                    )
                }

                else -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 16.dp)
                    ) {
                        Spacer(modifier = Modifier.height(12.dp))

                        SearchBarComponent(
                            query = state.searchQuery,
                            onQueryChange = { query -> viewModel.onSearchQueryChange(query) }
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        if (state.filteredHeroes.isEmpty()) {
                            Box(
                                modifier = Modifier.fillMaxSize(),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "No se encontraron superhéroes.",
                                    style = MaterialTheme.typography.bodyLarge
                                )
                            }
                        } else {
                            LazyColumn(
                                verticalArrangement = Arrangement.spacedBy(12.dp),
                                contentPadding = PaddingValues(bottom = 16.dp)
                            ) {
                                items(
                                    items = state.filteredHeroes,
                                    key = { hero: Superhero -> hero.id }
                                ) { hero ->
                                    SuperheroCard(
                                        hero = hero,
                                        onClick = { onHeroClick(hero.id) }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
