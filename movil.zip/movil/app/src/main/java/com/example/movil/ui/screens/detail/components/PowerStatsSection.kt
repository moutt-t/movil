package com.example.movil.ui.screens.detail.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.movil.data.model.Powerstats

@Composable
fun PowerStatsSection(
    stats: Powerstats,
    modifier: Modifier = Modifier
) {
    DetailSectionCard(
        title = "⚡ Estadísticas de Poder",
        modifier = modifier
    ) {
        StatBar(label = "🧠 Inteligencia", value = stats.intelligence)
        StatBar(label = "💪 Fuerza", value = stats.strength)
        StatBar(label = "⚡ Velocidad", value = stats.speed)
        StatBar(label = "🛡️ Durabilidad", value = stats.durability)
        StatBar(label = "🔥 Poder", value = stats.power)
        StatBar(label = "⚔️ Combate", value = stats.combat)
    }
}

@Composable
private fun StatBar(
    label: String,
    value: Int
) {
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = label, style = MaterialTheme.typography.bodyMedium)
            Text(
                text = "$value / 100",
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { (value / 100f).coerceIn(0f, 1f) },
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(CircleShape),
            color = when {
                value >= 80 -> Color(0xFF2E7D32)
                value >= 50 -> Color(0xFFF57C00)
                else -> Color(0xFFD32F2F)
            },
            trackColor = MaterialTheme.colorScheme.surfaceVariant
        )
    }
}
