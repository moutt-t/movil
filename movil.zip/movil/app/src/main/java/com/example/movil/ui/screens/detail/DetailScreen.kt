package com.example.movil.ui.screens.detail

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.example.movil.ui.components.ErrorStateComponent
import com.example.movil.ui.components.LoadingStateComponent
import com.example.movil.ui.screens.detail.components.DetailSectionCard
import com.example.movil.ui.screens.detail.components.PowerStatsSection

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailScreen(
    heroId: Int,
    onBackClick: () -> Unit,
    viewModel: DetailViewModel = viewModel()
) {
    LaunchedEffect(heroId) {
        viewModel.loadSuperheroDetail(heroId)
    }

    val state by viewModel.detailState.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Detalle del Héroe", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Volver"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when {
                state.isLoading -> {
                    LoadingStateComponent(message = "Cargando detalles del superhéroe...")
                }

                state.error != null -> {
                    ErrorStateComponent(
                        message = state.error ?: "Error desconocido",
                        onRetry = { viewModel.loadSuperheroDetail(heroId) }
                    )
                }

                state.hero != null -> {
                    val hero = state.hero!!
                    val scrollState = rememberScrollState()

                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(scrollState)
                            .padding(16.dp)
                    ) {
                        // Header Card
                        Card(
                            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                AsyncImage(
                                    model = hero.images?.lg ?: hero.images?.md,
                                    contentDescription = hero.name,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(260.dp)
                                        .clip(RoundedCornerShape(16.dp))
                                )

                                Spacer(modifier = Modifier.height(16.dp))

                                Text(
                                    text = hero.name,
                                    style = MaterialTheme.typography.headlineMedium,
                                    fontWeight = FontWeight.Bold
                                )

                                val fullName = hero.biography?.fullName
                                if (!fullName.isNullOrBlank() && fullName != "-") {
                                    Text(
                                        text = fullName,
                                        style = MaterialTheme.typography.titleMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                                    )
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    val publisher = hero.biography?.publisher
                                    if (!publisher.isNullOrBlank()) {
                                        BadgeChip(
                                            text = publisher,
                                            containerColor = MaterialTheme.colorScheme.primaryContainer,
                                            contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                                        )
                                    }

                                    val alignment = hero.biography?.alignment
                                    if (!alignment.isNullOrBlank()) {
                                        val (bg, fg) = when (alignment.lowercase()) {
                                            "good" -> Color(0xFF2E7D32) to Color.White
                                            "bad" -> Color(0xFFC62828) to Color.White
                                            else -> Color(0xFF757575) to Color.White
                                        }
                                        BadgeChip(
                                            text = alignment.replaceFirstChar { it.uppercase() },
                                            containerColor = bg,
                                            contentColor = fg
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Powerstats
                        hero.powerstats?.let { stats ->
                            PowerStatsSection(stats = stats)
                            Spacer(modifier = Modifier.height(16.dp))
                        }

                        // Biography
                        hero.biography?.let { bio ->
                            DetailSectionCard(title = "📜 Biografía") {
                                InfoRow(label = "Lugar de nacimiento", value = bio.placeOfBirth)
                                InfoRow(label = "Primera aparición", value = bio.firstAppearance)
                                InfoRow(label = "Alter egos", value = bio.alterEgos)
                                if (!bio.aliases.isNullOrEmpty()) {
                                    InfoRow(label = "Alias", value = bio.aliases.joinToString(", "))
                                }
                            }
                            Spacer(modifier = Modifier.height(16.dp))
                        }

                        // Appearance
                        hero.appearance?.let { app ->
                            DetailSectionCard(title = "👤 Apariencia") {
                                InfoRow(label = "Género", value = app.gender)
                                InfoRow(label = "Raza", value = app.race)
                                InfoRow(label = "Altura", value = app.height?.joinToString(" / "))
                                InfoRow(label = "Peso", value = app.weight?.joinToString(" / "))
                                InfoRow(label = "Color de ojos", value = app.eyeColor)
                                InfoRow(label = "Color de cabello", value = app.hairColor)
                            }
                            Spacer(modifier = Modifier.height(16.dp))
                        }

                        // Work & Connections
                        DetailSectionCard(title = "💼 Trabajo y Conexiones") {
                            InfoRow(label = "Ocupación", value = hero.work?.occupation)
                            InfoRow(label = "Base de operaciones", value = hero.work?.base)
                            InfoRow(label = "Afiliación a grupos", value = hero.connections?.groupAffiliation)
                            InfoRow(label = "Parientes", value = hero.connections?.relatives)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun InfoRow(
    label: String,
    value: String?
) {
    if (!value.isNullOrBlank() && value != "-") {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp)
        ) {
            Text(
                text = "$label: ",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = value,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun BadgeChip(
    text: String,
    containerColor: Color,
    contentColor: Color
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = containerColor
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold,
            color = contentColor,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
        )
    }
}
