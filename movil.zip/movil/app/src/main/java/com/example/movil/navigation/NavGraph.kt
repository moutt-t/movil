package com.example.movil.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.movil.ui.screens.detail.DetailScreen
import com.example.movil.ui.screens.home.HomeScreen

object NavDestinations {
    const val HOME = "home"
    const val DETAIL = "detail/{heroId}"
    fun createDetailRoute(heroId: Int) = "detail/$heroId"
}

@Composable
fun NavGraph(
    navController: NavHostController = rememberNavController()
) {
    NavHost(
        navController = navController,
        startDestination = NavDestinations.HOME
    ) {
        composable(NavDestinations.HOME) {
            HomeScreen(
                onHeroClick = { heroId ->
                    navController.navigate(NavDestinations.createDetailRoute(heroId))
                }
            )
        }

        composable(
            route = NavDestinations.DETAIL,
            arguments = listOf(
                navArgument("heroId") {
                    type = NavType.IntType
                }
            )
        ) { backStackEntry ->
            val heroId = backStackEntry.arguments?.getInt("heroId") ?: 1
            DetailScreen(
                heroId = heroId,
                onBackClick = {
                    navController.popBackStack()
                }
            )
        }
    }
}
