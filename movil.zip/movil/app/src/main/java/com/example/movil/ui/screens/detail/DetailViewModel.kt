package com.example.movil.ui.screens.detail

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.movil.data.repository.SuperheroRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class DetailViewModel(
    private val repository: SuperheroRepository = SuperheroRepository()
) : ViewModel() {

    private val _detailState = MutableStateFlow(DetailState())
    val detailState: StateFlow<DetailState> = _detailState.asStateFlow()

    fun loadSuperheroDetail(heroId: Int) {
        viewModelScope.launch {
            _detailState.update { it.copy(isLoading = true, error = null) }
            repository.getSuperheroById(heroId).fold(
                onSuccess = { hero ->
                    _detailState.update {
                        it.copy(
                            isLoading = false,
                            hero = hero,
                            error = null
                        )
                    }
                },
                onFailure = { error ->
                    _detailState.update {
                        it.copy(
                            isLoading = false,
                            error = error.localizedMessage ?: "Error al obtener los detalles del héroe"
                        )
                    }
                }
            )
        }
    }
}
