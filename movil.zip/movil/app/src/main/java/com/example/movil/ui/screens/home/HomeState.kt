package com.example.movil.ui.screens.home

import com.example.movil.data.model.Superhero

data class HomeState(
    val superheroes: List<Superhero> = emptyList(),
    val filteredHeroes: List<Superhero> = emptyList(),
    val searchQuery: String = "",
    val isLoading: Boolean = false,
    val error: String? = null
)
