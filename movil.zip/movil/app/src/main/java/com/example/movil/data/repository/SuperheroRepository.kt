package com.example.movil.data.repository

import com.example.movil.data.model.Superhero
import com.example.movil.data.remote.SuperheroApiService
import com.example.movil.data.remote.RetrofitClient

class SuperheroRepository(
    private val apiService: SuperheroApiService = RetrofitClient.apiService
) {

    suspend fun getSuperheroes(): Result<List<Superhero>> {
        return try {
            val response = apiService.getSuperheroes()
            if (response.isSuccessful) {
                val body = response.body()
                if (body != null) {
                    Result.success(body)
                } else {
                    Result.failure(Exception("La respuesta está vacía"))
                }
            } else {
                Result.failure(Exception("Error en la petición: ${response.code()} ${response.message()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getSuperheroById(id: Int): Result<Superhero> {
        return try {
            val response = apiService.getSuperheroById(id)
            if (response.isSuccessful) {
                val body = response.body()
                if (body != null) {
                    Result.success(body)
                } else {
                    Result.failure(Exception("Héroe no encontrado"))
                }
            } else {
                Result.failure(Exception("Error en la petición: ${response.code()} ${response.message()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
