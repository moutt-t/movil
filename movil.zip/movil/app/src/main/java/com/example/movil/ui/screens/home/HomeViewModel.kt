package com.example.movil.ui.screens.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.movil.data.model.Superhero
import com.example.movil.data.repository.SuperheroRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class HomeViewModel(
    private val repository: SuperheroRepository = SuperheroRepository()
) : ViewModel() {

    private val _homeState = MutableStateFlow(HomeState())
    val homeState: StateFlow<HomeState> = _homeState.asStateFlow()

    init {
        loadSuperheroes()
    }

    fun loadSuperheroes() {
        viewModelScope.launch {
            _homeState.update { it.copy(isLoading = true, error = null) }
            repository.getSuperheroes().fold(
                onSuccess = { heroes ->
                    _homeState.update {
                        it.copy(
                            isLoading = false,
                            superheroes = heroes,
                            filteredHeroes = heroes,
                            error = null
                        )
                    }
                },
                onFailure = { error ->
                    _homeState.update {
                        it.copy(
                            isLoading = false,
                            error = error.localizedMessage ?: "Error al cargar los superhéroes"
                        )
                    }
                }
            )
        }
    }

    fun onSearchQueryChange(query: String) {
        val currentHeroes = _homeState.value.superheroes
        val filtered = if (query.isBlank()) {
            currentHeroes
        } else {
            currentHeroes.filter { hero ->
                hero.name.contains(query, ignoreCase = true) ||
                        (hero.biography?.fullName?.contains(query, ignoreCase = true) == true) ||
                        (hero.biography?.publisher?.contains(query, ignoreCase = true) == true)
            }
        }
        _homeState.update {
            it.copy(
                filteredHeroes = filtered,
                searchQuery = query
            )
        }
    }
}
